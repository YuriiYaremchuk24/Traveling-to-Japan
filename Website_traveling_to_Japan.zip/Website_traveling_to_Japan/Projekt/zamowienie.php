<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Kod PHP do obsługi zapisywania danych do bazy
    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "logowanie";

    $conn = new mysqli($host, $user, $password, $database);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $imie = mysqli_real_escape_string($conn, $_POST['imie']);
        $nazwisko = mysqli_real_escape_string($conn, $_POST['nazwisko']);
        $iloscOsob = mysqli_real_escape_string($conn, $_POST['ilosc_osob']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $numerTelefonu = mysqli_real_escape_string($conn, $_POST['numer_telefonu']);
        $miasto = mysqli_real_escape_string($conn, $_POST['miasto']);
        $klasa = mysqli_real_escape_string($conn, $_POST['klasa']);

        $sql = "INSERT INTO Rezerwacje (Imie, Nazwisko, IloscOsob, Email, NumerTelefonu, Miasto, Klasa)
                VALUES ('$imie', '$nazwisko', '$iloscOsob', '$email', '$numerTelefonu', '$miasto', '$klasa')";

    if ($conn->query($sql) === TRUE) {
        echo "<p>Rezerwacja zapisana pomyślnie!</p>";
    } else {
        echo "<p>Błąd podczas zapisywania rezerwacji: " . $conn->error . "</p>";
    }

    $conn->close();
}
?>
